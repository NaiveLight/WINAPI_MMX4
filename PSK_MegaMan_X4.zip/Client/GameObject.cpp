#include "stdafx.h"
#include "GameObject.h"


CGameObject::CGameObject()
	:m_tInfo({}), m_tTexRect({}), m_tHitBoxRect({}), m_iHitBoxCX(0), m_iHitBoxCY(0),
	m_tFrame({}), m_pFrameKey(nullptr), m_pTarget(nullptr),
	m_bIsInit(false), m_bIsActive(false), m_bIsLeft(false), 
	m_iFrameCnt(1), m_iSceneCnt(1),  m_fMaxSpeed(0.f)
{
}


CGameObject::~CGameObject()
{
}

// ��� �ڽ�Ŭ������ Update���� LateInit�� �ѹ� �����ϰ� ��
// �������̵� �ʼ�.
void CGameObject::LateInit()
{
	if (!m_bIsInit)
	{
		this->LateInit();
		m_bIsInit = true;
	}
}

// ������Ʈ�� ��ġ�� ���� Rect ũ�� ����
void CGameObject::UpdateRect()
{
	m_tTexRect.left = LONG(m_tInfo.fX - m_tInfo.fCX / 2);
	m_tTexRect.top = LONG(m_tInfo.fY - m_tInfo.fCY / 2);
	m_tTexRect.right = LONG(m_tInfo.fX + m_tInfo.fCX / 2);
	m_tTexRect.bottom = LONG(m_tInfo.fY + m_tInfo.fCY / 2);

	m_tHitBoxRect.left = LONG(m_tInfo.fX - m_iHitBoxCX / 2);
	m_tHitBoxRect.top = LONG(m_tInfo.fY - m_iHitBoxCY / 2);
	m_tHitBoxRect.right = LONG(m_tInfo.fX + m_iHitBoxCX / 2);
	m_tHitBoxRect.bottom = LONG(m_tInfo.fY + m_iHitBoxCY / 2);
}

//// ������Ʈ�� ��ġ�� ���� Rect ũ�� ����
//void CGameObject::UpdateRect(float fX, float fY)
//{
//}

// 1������ ���� �ִϸ��̼� ����
void CGameObject::FrameMove()
{
	if (m_tFrame.dwTime + m_tFrame.dwSpeed < GetTickCount())
	{
		++m_tFrame.iStart;
		m_tFrame.dwTime = GetTickCount();
	}

	if (m_tFrame.iStart > m_tFrame.iEnd)
	{
		m_tFrame.iStart = 0;
	}
}

// ������ Ű�� �ش��ϴ� �̹��� �׸���
void CGameObject::DrawObject(HDC hDC, const TCHAR * pFrameKey)
{
	CMyBmp* pBmp = BmpManager->FindImage(pFrameKey);

	int iSizeX = pBmp->GetBmpCX() / (m_iFrameCnt);
	int iSizeY = pBmp->GetBmpCY() / (m_iSceneCnt);

	GdiTransparentBlt(hDC, m_tTexRect.left, m_tTexRect.top, (int)m_tInfo.fCX, (int)m_tInfo.fCY, pBmp->GetMemDC(),
		m_tFrame.iStart * iSizeX, m_tFrame.iScene * iSizeY, iSizeX, iSizeY, RGB(255, 0, 255));
}


void CGameObject::DrawObjectScroll(HDC hDC, const TCHAR * pFrameKey)
{
	int iScrollX = (int) GameManager->GetScrollX();
	int iScrollY = (int) GameManager->GetScrollY();

	CMyBmp* pBmp = BmpManager->FindImage(pFrameKey);

	int iSizeX = pBmp->GetBmpCX() / (m_iFrameCnt);
	int iSizeY = pBmp->GetBmpCY() / (m_iSceneCnt);

	GdiTransparentBlt(hDC, m_tTexRect.left - iScrollX, m_tTexRect.top - iScrollY, (int)m_tInfo.fCX, (int)m_tInfo.fCY, pBmp->GetMemDC(),
						m_tFrame.iStart * iSizeX, m_tFrame.iScene * iSizeY, iSizeX, iSizeY, RGB(255, 0, 255));
}

void CGameObject::DrawObjectMaxScroll(HDC hDC, const TCHAR * pFrameKey)
{
	int iScrollX = (int)GameManager->GetMaxScrollX();
	int iScrollY = (int)GameManager->GetMaxScrollY();

	CMyBmp* pBmp = BmpManager->FindImage(pFrameKey);

	int iSizeX = pBmp->GetBmpCX() / (m_iFrameCnt);
	int iSizeY = pBmp->GetBmpCY() / (m_iSceneCnt);

	GdiTransparentBlt(hDC, m_tTexRect.left + iScrollX, m_tTexRect.top - iScrollY, (int)m_tInfo.fCX, (int)m_tInfo.fCY, pBmp->GetMemDC(),
		m_tFrame.iStart * iSizeX, m_tFrame.iScene * iSizeY, iSizeX, iSizeY, RGB(255, 0, 255));
}

void CGameObject::DrawHitBox(HDC hDC)
{
	Rectangle(hDC, m_tHitBoxRect.left, m_tHitBoxRect.top, m_tHitBoxRect.right, m_tHitBoxRect.bottom);
}

