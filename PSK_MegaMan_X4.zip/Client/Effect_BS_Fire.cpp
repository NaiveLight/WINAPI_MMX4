#include "stdafx.h"
#include "Effect_BS_Fire.h"


CEffect_BS_Fire::CEffect_BS_Fire()
{
}


CEffect_BS_Fire::~CEffect_BS_Fire()
{
}

void CEffect_BS_Fire::Init()
{
}

OBJECT_STATE CEffect_BS_Fire::Update()
{
	return OBJECT_STATE();
}

void CEffect_BS_Fire::LateUpdate()
{
}

void CEffect_BS_Fire::Render(HDC hDC)
{
}

void CEffect_BS_Fire::Release()
{
}
