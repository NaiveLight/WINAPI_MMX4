#include "stdafx.h"
#include "TileManager.h"


CTileManager::CTileManager()
{
}


CTileManager::~CTileManager()
{
}
