#include "stdafx.h"
#include "Loading.h"


CLoading::CLoading()
{
}


CLoading::~CLoading()
{
}

void CLoading::Init()
{
}

void CLoading::Update()
{
}

void CLoading::LateUpdate()
{
}

void CLoading::Render(HDC hDC)
{
}

void CLoading::Release()
{
}
