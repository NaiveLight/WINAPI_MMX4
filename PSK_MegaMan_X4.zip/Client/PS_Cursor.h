#pragma once
#include "GameObject.h"
class CPS_Cursor :
	public CGameObject
{
private:
	CGameObject* m_pX;
	CGameObject* m_pZero;
	bool m_bIsSeleted;

public:
	CPS_Cursor();
	virtual ~CPS_Cursor();

	// CGameObject��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void LateInit() override;
	virtual OBJECT_STATE Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

public:
	const bool& GetIsSelected() { return m_bIsSeleted;}

public:
	void SetTargetX(CGameObject* pObj) { m_pX = pObj; }
	void SetTargetZero(CGameObject* pObj) { m_pZero = pObj; }
};

