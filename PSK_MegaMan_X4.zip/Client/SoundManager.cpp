#include "stdafx.h"
#include "SoundManager.h"


CSoundManager::CSoundManager()
{
}


CSoundManager::~CSoundManager()
{
}
