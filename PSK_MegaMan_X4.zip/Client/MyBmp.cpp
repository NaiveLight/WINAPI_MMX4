#include "stdafx.h"
#include "MyBmp.h"


CMyBmp::CMyBmp()
{
}


CMyBmp::~CMyBmp()
{
	Release();
}

void CMyBmp::LoadBmp(const TCHAR * pFilePath)
{
	m_hDC = GetDC(g_hWnd);

	//CreateCompatibleDC : ���� ȭ�� DC�� ȣȯ�Ǵ� �޸� DC �Ҵ�
	m_hMemDC = CreateCompatibleDC(m_hDC);
	ReleaseDC(g_hWnd, m_hDC);

	m_hBitmap = (HBITMAP)LoadImage(nullptr, pFilePath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);

	m_hOld = (HBITMAP)SelectObject(m_hMemDC, m_hBitmap);

	BITMAP tempBmp = {};
	GetObject(m_hBitmap, sizeof(tempBmp), &tempBmp);

	iSizeX = tempBmp.bmWidth;
	iSizeY = tempBmp.bmHeight;
}

void CMyBmp::Release()
{
	SelectObject(m_hMemDC, m_hOld);
	DeleteObject(m_hBitmap);
	DeleteDC(m_hMemDC);
}
