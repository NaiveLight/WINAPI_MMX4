#pragma once

class CSoundManager :
	public CSingleton<CSoundManager>
{
public:
	CSoundManager();
	virtual ~CSoundManager();
};

