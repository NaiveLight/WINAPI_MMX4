#pragma once

typedef list<class CGameObject*> OBJLIST;
typedef unordered_map<const TCHAR*, class CMyBmp*> BMPMAP;
typedef unordered_map<const TCHAR*, FMOD_SOUND*> SOUNDMAP;